package org.montanajr.kolo02;

public interface Expression {
    String interpret(InterpreterContext ic);
}
