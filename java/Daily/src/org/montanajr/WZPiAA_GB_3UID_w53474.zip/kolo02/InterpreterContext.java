package org.montanajr.kolo02;

public interface InterpreterContext {
     String launchDecoder(String code);
}
